# Prisma Game Dev Studio — app para Android

Este é o seu editor HTML rodando dentro de um app nativo. Ele **não** é um
navegador comum: a WebView aqui foi configurada para dar ao jogo mais memória e
mais recursos do que Chrome ou Firefox liberam para uma página local.

## O que o app libera

| Recurso | Efeito no Prisma |
|---|---|
| `largeHeap="true"` | Memória bem maior por app. Sprites e áudios em base64 param de travar o editor. |
| Aceleração por GPU | Camada de hardware na WebView: rolagem e animação mais lisas. |
| `DomStorage` liberado | O "Salvar Projeto" persiste de verdade entre sessões. |
| Áudio sem gesto | Música de fundo toca sozinha, sem precisar tocar na tela antes. |
| Seletor de arquivos | Os botões "Carregar" abrem a galeria/arquivos do celular. |
| Download de `blob:` | O botão 🚀 grava `meu_jogo_standalone.html` na pasta Downloads. |
| Prioridade de renderização | O Android evita rebaixar a WebView quando a memória aperta. |
| Tela cheia + tela ligada | Sem barras do sistema e sem o celular apagar durante o teste. |
| `blockNetworkLoads` | 100% offline. Nada sai do aparelho. |

---

## Caminho 1 — gerar o APK sem instalar nada (recomendado)

1. Crie um repositório novo no GitHub (pode ser privado).
2. Envie **todo o conteúdo desta pasta** para lá (botão *Add file → Upload files*
   aceita arrastar a pasta inteira).
3. Abra a aba **Actions** do repositório e autorize os workflows.
4. Clique em **Gerar APK → Run workflow**.
5. Em poucos minutos, baixe o arquivo **prisma-game-dev-studio-apk** que aparece
   ao final da execução. Dentro dele está o `app-debug.apk`.

Para instalar: copie o APK para o celular, toque nele e autorize
"instalar de fontes desconhecidas".

## Caminho 2 — Android Studio

1. **File → Open** e escolha esta pasta.
2. Espere o Gradle sincronizar (ele cria o wrapper sozinho).
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

---

## Atualizar o jogo depois

O editor inteiro é o arquivo:

    app/src/main/assets/jogo.html

Troque esse arquivo pela versão nova do seu HTML e gere o APK de novo. Nada mais
precisa mudar.

## Ajustes rápidos

- **Nome do app**: `app/src/main/res/values/strings.xml`
- **Ícone**: `app/src/main/res/drawable/ic_launcher_foreground.xml`
- **Travar em paisagem**: no `AndroidManifest.xml`, troque
  `android:screenOrientation="fullSensor"` por `"sensorLandscape"`
- **Identificador do app**: `applicationId` em `app/build.gradle`
  (mude se for publicar na Play Store)

## Observação sobre memória

`largeHeap` aumenta o limite, mas quem define o teto real é o fabricante do
aparelho — costuma ir de ~256 MB para 512 MB ou mais. Se um projeto muito pesado
ainda travar, o gargalo passa a ser a quantidade de imagens em base64 guardadas
no projeto, não o app.
