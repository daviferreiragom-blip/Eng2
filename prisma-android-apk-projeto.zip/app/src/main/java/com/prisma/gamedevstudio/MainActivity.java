package com.prisma.gamedevstudio;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Casca nativa do Prisma Game Dev Studio.
 *
 * O editor inteiro é o HTML em assets/jogo.html. Esta Activity existe para dar
 * a ele o que um navegador comum não dá:
 *
 *   • memória grande  (largeHeap no manifesto) — sprites em base64 cabem folgado;
 *   • aceleração por GPU — animação e rolagem mais lisas;
 *   • armazenamento local liberado — o "Salvar Projeto" não se perde;
 *   • áudio sem gesto do usuário — a música de fundo toca sozinha;
 *   • seletor de arquivos — os botões "Carregar" abrem a galeria do celular;
 *   • download do jogo exportado — o botão 🚀 grava o HTML em Downloads;
 *   • tela cheia imersiva e tela sempre ligada.
 */
public class MainActivity extends Activity {

    private static final int REQ_ARQUIVO = 1001;

    private WebView web;
    private ValueCallback<Uri[]> retornoArquivo;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        configurarWebView();

        web.addJavascriptInterface(new Ponte(), "PrismaAndroid");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener(this::aoBaixar);

        if (estado != null) web.restoreState(estado);
        else web.loadUrl("file:///android_asset/jogo.html");
    }

    // ------------------------------------------------------------------
    // Configuração da WebView — é aqui que mora o ganho de desempenho.
    // ------------------------------------------------------------------
    private void configurarWebView() {
        WebSettings s = web.getSettings();

        s.setJavaScriptEnabled(true);

        // Guarda o projeto do usuário (localStorage). Sem isto, tudo se perde ao fechar.
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);

        // O HTML roda a partir de file://; estas três liberam sprites, áudios e
        // o blob do jogo exportado.
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        // Música de fundo e efeitos tocam sem esperar um toque na tela.
        s.setMediaPlaybackRequiresUserGesture(false);

        // Layout do jogo em pixels reais, sem o zoom automático do navegador
        // e sem o tamanho de fonte do sistema desmontando a interface.
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);

        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkLoads(true);   // 100% offline: nada sai do aparelho

        // Cada camada da WebView é desenhada pela GPU.
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }
    }

    // ------------------------------------------------------------------
    // Tela cheia imersiva
    // ------------------------------------------------------------------
    @Override
    public void onWindowFocusChanged(boolean temFoco) {
        super.onWindowFocusChanged(temFoco);
        if (!temFoco) return;
        web.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ------------------------------------------------------------------
    // Seletor de arquivos: faz os botões "Carregar" abrirem a galeria.
    // ------------------------------------------------------------------
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> retorno,
                                         FileChooserParams params) {
            if (retornoArquivo != null) retornoArquivo.onReceiveValue(null);
            retornoArquivo = retorno;
            try {
                startActivityForResult(params.createIntent(), REQ_ARQUIVO);
            } catch (Exception e) {
                retornoArquivo = null;
                aviso("Não foi possível abrir o seletor de arquivos.");
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int req, int resultado, Intent dados) {
        if (req != REQ_ARQUIVO) { super.onActivityResult(req, resultado, dados); return; }
        if (retornoArquivo == null) return;
        retornoArquivo.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(resultado, dados));
        retornoArquivo = null;
    }

    // ------------------------------------------------------------------
    // Download do jogo exportado (botão 🚀).
    // A exportação cria um blob: — que a WebView não sabe baixar sozinha.
    // Então pedimos ao próprio JavaScript que leia o blob e nos devolva
    // o conteúdo, e gravamos o arquivo pelo lado nativo.
    // ------------------------------------------------------------------
    private void aoBaixar(String url, String userAgent, String disposicao,
                          String mime, long tamanho) {
        String nome = "meu_jogo_standalone.html";
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            String js =
                    "(function(){fetch('" + url + "').then(r=>r.blob()).then(b=>{" +
                    "var fr=new FileReader();" +
                    "fr.onloadend=function(){PrismaAndroid.salvarArquivo(fr.result,'" + nome + "');};" +
                    "fr.readAsDataURL(b);}).catch(function(e){" +
                    "PrismaAndroid.falhaAoSalvar(String(e));});})();";
            web.evaluateJavascript(js, null);
        } else {
            aviso("Este download não é suportado dentro do app.");
        }
    }

    /** Ponte chamada pelo JavaScript da página. */
    private class Ponte {
        @JavascriptInterface
        public void salvarArquivo(String dataUrl, String nome) {
            try {
                int virgula = dataUrl.indexOf(',');
                byte[] bytes = Base64.decode(dataUrl.substring(virgula + 1), Base64.DEFAULT);
                String destino = gravarEmDownloads(nome, bytes);
                runOnUiThread(() -> aviso("Jogo exportado em " + destino));
            } catch (Exception e) {
                runOnUiThread(() -> aviso("Erro ao salvar: " + e.getMessage()));
            }
        }

        @JavascriptInterface
        public void falhaAoSalvar(String erro) {
            runOnUiThread(() -> aviso("Erro ao exportar: " + erro));
        }
    }

    private String gravarEmDownloads(String nome, byte[] bytes) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, nome);
            cv.put(MediaStore.Downloads.MIME_TYPE, "text/html");
            cv.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri destino = getContentResolver()
                    .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            try (OutputStream out = getContentResolver().openOutputStream(destino)) {
                out.write(bytes);
            }
            cv.clear();
            cv.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(destino, cv, null, null);
            return "Downloads/" + nome;
        }
        File pasta = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS);
        if (!pasta.exists()) pasta.mkdirs();
        File arquivo = new File(pasta, nome);
        try (FileOutputStream out = new FileOutputStream(arquivo)) {
            out.write(bytes);
        }
        return arquivo.getAbsolutePath();
    }

    private void aviso(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------
    @Override protected void onSaveInstanceState(Bundle fora) {
        super.onSaveInstanceState(fora);
        web.saveState(fora);
    }

    @Override protected void onPause()  { web.onPause();  super.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
