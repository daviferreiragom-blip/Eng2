# A ponte JavaScript é chamada por nome pela página; nunca renomear.
-keepclassmembers class com.prisma.gamedevstudio.MainActivity$Ponte {
   public *;
}
